OC.L10N.register(
    "groupfolders",
    {
    "Group" : "กลุ่ม",
    "Read" : "อ่าน",
    "Create" : "สร้าง",
    "Delete" : "ลบ",
    "Share" : "แชร์",
    "Add group" : "เพิ่มกลุ่ม",
    "Unlimited" : "ไม่จำกัด",
    "Folder name" : "ชื่อโฟลเดอร์",
    "Quota" : "โควต้า",
    "Previous" : "ก่อนหน้า",
    "Next" : "ถัดไป",
    "User" : "ผู้ใช้",
    "Unknown" : "ไม่ทราบ",
    "None" : "ไม่มี",
    "{size} used" : "ใช้ไป {size}"
},
"nplurals=1; plural=0;");
