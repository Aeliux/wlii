OC.L10N.register(
    "groupfolders",
    {
    "Deny" : "Rechazar",
    "Allow" : "Permitir",
    "Group" : "Grupo",
    "Read" : "Leer",
    "Write" : "Escribir",
    "Create" : "Crear",
    "Delete" : "Eliminar",
    "Share" : "Compartir",
    "You" : "Usted",
    "Add group" : "Agregar grupo",
    "Unlimited" : "Ilimitado",
    "Folder name" : "Nombre de la carpeta",
    "Quota" : "Cuota",
    "Previous" : "Anterior",
    "User" : "Usuario",
    "Unknown" : "Desconocido",
    "None" : "Ninguno",
    "{size} used" : "{size} usados",
    "Unset" : "Desconectado"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
