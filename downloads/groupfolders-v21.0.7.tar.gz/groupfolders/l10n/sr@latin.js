OC.L10N.register(
    "groupfolders",
    {
    "Deny" : "Odbij",
    "Allow" : "Dozvoli",
    "Group" : "Group",
    "Read" : "Čitaj",
    "Create" : "Napravi",
    "Delete" : "Delete",
    "Share" : "Deljenje",
    "Folder name" : "Naziv fascikle",
    "User" : "Korisnik",
    "None" : "Ništa",
    "{size} used" : "{size} iskorišćeno",
    "Unset" : "Ukloni"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
