OC.L10N.register(
    "groupfolders",
    {
    "Access denied" : "წვდომა არაა დაშვებული",
    "Group" : "ჯგუფი",
    "Read" : "წაკითხვა",
    "Write" : "ჩაწერა",
    "Create" : "შექმნა",
    "Delete" : "წაშლა",
    "Share" : "გაზიარება",
    "You" : "თქვენ",
    "Add group" : "ჯგუფის დამატება",
    "Default" : "საწყისი პარამეტრები",
    "Unlimited" : "ულიმიტო",
    "Delete \"{folderName}\"?" : "გავაუქმოთ \"{folderName}\"?",
    "Folder name" : "დირექტორიის სახელი",
    "Quota" : "ქვოტა",
    "Previous" : "წინა",
    "User" : "მომხმარებელი",
    "Unknown" : "უცნობია",
    "None" : "არც ერთი",
    "{size} used" : "მოხმარებულია {size}"
},
"nplurals=2; plural=(n!=1);");
