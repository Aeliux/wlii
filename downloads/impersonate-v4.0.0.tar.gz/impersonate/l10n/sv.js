OC.L10N.register(
    "impersonate",
    {
    "Could not impersonate user" : "Kunde inte imitera användare",
    "Are you sure you want to impersonate \"{userId}\"?" : "Är du säker att du vill imitera \"{userId}\"?",
    "Impersonate user" : "Imitera användare",
    "Impersonate" : "Imitera",
    "Could not log out, please try again" : "Det gick inte att logga ut, försök igen",
    "Logged in as {name} ({uid})" : "Inloggad som {name} ({uid})",
    "User not found" : "Användaren hittades inte",
    "Insufficient permissions to impersonate user" : "Otillräckliga behörigheter för att imitera användare",
    "Cannot impersonate the user because it was never logged in" : "Kan inte imitera användaren eftersom de aldrig varit inloggade",
    "Cannot impersonate yourself" : "Kan inte imitera dig själv",
    "Impersonate other users" : "Imitera andra användare",
    "These groups will be able to impersonate users they are allowed to administrate. If you remove all groups, every group administrator will be allowed to impersonate." : "Dessa grupper kommer att kunna imitera användare som de får administrera. Om du tar bort alla grupper får varje gruppadministratör imitera."
},
"nplurals=2; plural=(n != 1);");
