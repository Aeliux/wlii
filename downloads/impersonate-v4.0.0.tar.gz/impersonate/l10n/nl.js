OC.L10N.register(
    "impersonate",
    {
    "Could not impersonate user" : "Kon gebruiker niet nabootsen",
    "Are you sure you want to impersonate \"{userId}\"?" : "Weet je zeker dat je \"{userId}\" wilt nabootsen?",
    "Impersonate user" : "Gebruiker nabootsen",
    "Impersonate" : "Nabootsen",
    "Could not log out, please try again" : "Kan niet uitloggen, probeer het opnieuw",
    "Logged in as {name} ({uid})" : "Ingelogd als {name} ({uid})",
    "User not found" : "Gebruiker niet gevonden",
    "Insufficient permissions to impersonate user" : "Onvoldoende machtigingen om andere account na te bootsen.",
    "Cannot impersonate the user because it was never logged in" : "Kan zich niet voordoen als de gebruiker omdat deze nooit is ingelogd",
    "Cannot impersonate yourself" : "Je kunt je niet voordoen als jezelf",
    "Impersonate other users" : "Andere gebruiker nabootsen",
    "By installing the impersonate app of your Nextcloud you enable administrators to impersonate other users on the Nextcloud server. This is especially useful for debugging issues reported by users.\n\nTo impersonate a user an administrator has to simply follow the following four steps:\n\n1. Login as administrator to Nextcloud.\n2. Open users administration interface.\n3. Select the impersonate button on the affected user.\n4. Confirm the impersonation.\n\nThe administrator is then logged-in as the user, to switch back to the regular user account they simply have to press the logout button.\n\n**Note:**\n\n- This app is not compatible with instances that have encryption enabled.\n- While impersonate actions are logged note that actions performed impersonated will be logged as the impersonated user.\n- Impersonating a user is only possible after their first login.\n- You can limit which users/groups can use impersonation in Administration settings > Additional settings." : "Door de imitate-app van jouw Nextcloud te installeren, stel je beheerders in staat zich voor te doen als andere gebruikers op de Nextcloud-server. Dit is vooral handig voor foutopsporingsproblemen die door gebruikers worden gemeld.\n\nOm zich voor te doen als een gebruiker moet een beheerder eenvoudigweg de volgende vier stappen volgen:\n\n1. Login als beheerder bij Nextcloud.\n2. Open gebruikers administratie interface.\n3. Selecteer de imitatieknop op de getroffen gebruiker.\n4. Bevestig de nabootsing.\n\nDe beheerder wordt vervolgens ingelogd als gebruiker. Om terug te schakelen naar het reguliere gebruikersaccount hoeft hij alleen maar op de uitlogknop te drukken.\n\n**Opmerking:**\n\n- Deze app is niet compatibel met instanties waarvoor encryptie is ingeschakeld.\n- Terwijl nagebootste acties worden geregistreerd, moet u er rekening mee houden dat acties die nagebootst worden, worden geregistreerd als de nagebootste gebruiker.\n- Het zich voordoen als een gebruiker is alleen mogelijk na hun eerste aanmelding.\n- U kunt beperken welke gebruikers/groepen imitatie kunnen gebruiken in Beheerinstellingen > Aanvullende instellingen.",
    "These groups will be able to impersonate users they are allowed to administrate. If you remove all groups, every group administrator will be allowed to impersonate." : "Deze groepen kunnen andere gebruikers nabootsen als ze bevoegd zijn om te beheren. Als je alle groepen verwijdert, kan iedere groepsbeheerder gebruikers nabootsen."
},
"nplurals=2; plural=(n != 1);");
