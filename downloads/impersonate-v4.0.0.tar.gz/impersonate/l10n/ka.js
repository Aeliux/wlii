OC.L10N.register(
    "impersonate",
    {
    "Could not impersonate user" : "Could not impersonate user",
    "Are you sure you want to impersonate \"{userId}\"?" : "Are you sure you want to impersonate \"{userId}\"?",
    "Impersonate user" : "Impersonate user",
    "Impersonate" : "Impersonate",
    "Could not log out, please try again" : "Could not log out, please try again",
    "Logged in as {name} ({uid})" : "Logged in as {name} ({uid})",
    "User not found" : "User not found",
    "Insufficient permissions to impersonate user" : "Insufficient permissions to impersonate user",
    "Cannot impersonate the user because it was never logged in" : "Cannot impersonate the user because it was never logged in",
    "Cannot impersonate yourself" : "Cannot impersonate yourself",
    "Impersonate other users" : "Impersonate other users",
    "By installing the impersonate app of your Nextcloud you enable administrators to impersonate other users on the Nextcloud server. This is especially useful for debugging issues reported by users.\n\nTo impersonate a user an administrator has to simply follow the following four steps:\n\n1. Login as administrator to Nextcloud.\n2. Open users administration interface.\n3. Select the impersonate button on the affected user.\n4. Confirm the impersonation.\n\nThe administrator is then logged-in as the user, to switch back to the regular user account they simply have to press the logout button.\n\n**Note:**\n\n- This app is not compatible with instances that have encryption enabled.\n- While impersonate actions are logged note that actions performed impersonated will be logged as the impersonated user.\n- Impersonating a user is only possible after their first login.\n- You can limit which users/groups can use impersonation in Administration settings > Additional settings." : "By installing the impersonate app of your Nextcloud you enable administrators to impersonate other users on the Nextcloud server. This is especially useful for debugging issues reported by users.\n\nTo impersonate a user an administrator has to simply follow the following four steps:\n\n1. Login as administrator to Nextcloud.\n2. Open users administration interface.\n3. Select the impersonate button on the affected user.\n4. Confirm the impersonation.\n\nThe administrator is then logged-in as the user, to switch back to the regular user account they simply have to press the logout button.\n\n**Note:**\n\n- This app is not compatible with instances that have encryption enabled.\n- While impersonate actions are logged note that actions performed impersonated will be logged as the impersonated user.\n- Impersonating a user is only possible after their first login.\n- You can limit which users/groups can use impersonation in Administration settings > Additional settings.",
    "These groups will be able to impersonate users they are allowed to administrate. If you remove all groups, every group administrator will be allowed to impersonate." : "These groups will be able to impersonate users they are allowed to administrate. If you remove all groups, every group administrator will be allowed to impersonate."
},
"nplurals=2; plural=(n!=1);");
