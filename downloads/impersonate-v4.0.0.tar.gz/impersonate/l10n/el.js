OC.L10N.register(
    "impersonate",
    {
    "Could not impersonate user" : "Αδύνατη η προσωποποίηση του χρήστη",
    "Are you sure you want to impersonate \"{userId}\"?" : "Είστε βέβαιοι ότι θέλετε να προσωποποιήσετε τον \"{userId}\"; ",
    "Impersonate user" : "Προσωποποίηση χρήστη",
    "Impersonate" : "Προσωποποίηση",
    "Could not log out, please try again" : "Αδυναμία αποσύνδεσης, παρακαλώ δοκιμάστε ξανά",
    "Logged in as {name} ({uid})" : "Συνδεδεμένος ως {name} ({uid})",
    "User not found" : "Ο χρήστης δεν βρέθηκε",
    "Insufficient permissions to impersonate user" : "Μη επαρκή δικαιώματα για εξομοίωση χρήστη",
    "Cannot impersonate the user because it was never logged in" : "Δεν είναι δυνατή η εξομοίωση του χρήστη επειδή δεν έχει συνδεθεί ποτέ",
    "Cannot impersonate yourself" : "Δεν μπορείτε να εξομοιώσετε τον εαυτό σας",
    "Impersonate other users" : "Εξομοιώστε άλλους χρήστες",
    "By installing the impersonate app of your Nextcloud you enable administrators to impersonate other users on the Nextcloud server. This is especially useful for debugging issues reported by users.\n\nTo impersonate a user an administrator has to simply follow the following four steps:\n\n1. Login as administrator to Nextcloud.\n2. Open users administration interface.\n3. Select the impersonate button on the affected user.\n4. Confirm the impersonation.\n\nThe administrator is then logged-in as the user, to switch back to the regular user account they simply have to press the logout button.\n\n**Note:**\n\n- This app is not compatible with instances that have encryption enabled.\n- While impersonate actions are logged note that actions performed impersonated will be logged as the impersonated user.\n- Impersonating a user is only possible after their first login.\n- You can limit which users/groups can use impersonation in Administration settings > Additional settings." : "Εγκαθιστώντας την εφαρμογή εξομοίωσης στο Nextcloud σας, επιτρέπετε στους διαχειριστές να εξομοιώνουν άλλους χρήστες στον διακομιστή Nextcloud. Αυτό είναι ιδιαίτερα χρήσιμο για τον εντοπισμό σφαλμάτων ζητημάτων που αναφέρουν οι χρήστες.\n\nΓια να εξομοιώσει έναν χρήστη, ένας διαχειριστής πρέπει απλώς να ακολουθήσει τα ακόλουθα τέσσερα βήματα:\n\n1. Σύνδεση ως διαχειριστής στο Nextcloud.\n2. Άνοιγμα της διεπαφής διαχείρισης χρηστών.\n3. Επιλογή του κουμπιού εξομοίωσης στον εν λόγω χρήστη.\n4. Επιβεβαίωση της εξομοίωσης.\n\nΟ διαχειριστής συνδέεται τότε ως ο χρήστης, για να επιστρέψει στον κανονικό λογαριασμό χρήστη πρέπει απλώς να πατήσει το κουμπί αποσύνδεσης.\n\n**Σημείωση:**\n\n- Αυτή η εφαρμογή δεν είναι συμβατή με περιπτώσεις που έχουν ενεργοποιημένη την κρυπτογράφηση.\n- Ενώ οι ενέργειες εξομοίωσης καταγράφονται, σημειώστε ότι οι ενέργειες που εκτελούνται εξομοιωμένες θα καταγραφούν ως ο εξομοιωμένος χρήστης.\n- Η εξομοίωση ενός χρήστη είναι δυνατή μόνο μετά την πρώτη σύνδεσή του.\n- Μπορείτε να περιορίσετε ποιοι χρήστες/ομάδες μπορούν να χρησιμοποιούν την εξομοίωση στις Ρυθμίσεις Διαχείρισης > Πρόσθετες ρυθμίσεις.",
    "These groups will be able to impersonate users they are allowed to administrate. If you remove all groups, every group administrator will be allowed to impersonate." : "Αυτές οι ομάδες θα είναι σε θέση να εξομοιώσουν τους χρήστες τους οποίους επιτρέπεται να διαχειρίζονται. Αν καταργήσετε όλες τις ομάδες, κάθε διαχειριστής ομάδας θα επιτρέπεται να εξομοιώσει.."
},
"nplurals=2; plural=(n != 1);");
