OC.L10N.register(
    "impersonate",
    {
    "Could not impersonate user" : "Неможливо знеособити користувача",
    "Are you sure you want to impersonate \"{userId}\"?" : "Ви впевнені, що хочете видати себе за \"{userId}\"?",
    "Impersonate user" : "Знеособити користувача",
    "Impersonate" : "Знеособити",
    "Could not log out, please try again" : "Не вдалося вийти з системи, спробуйте ще раз",
    "Logged in as {name} ({uid})" : "Увійшов в систему як {name} ({uid})",
    "User not found" : "Користувача не знайдено",
    "Insufficient permissions to impersonate user" : "Недостатньо дозволів для видачі себе за користувача ",
    "Cannot impersonate the user because it was never logged in" : "Не може видати себе за користувача, оскільки він ніколи не входив в систему ",
    "Cannot impersonate yourself" : "Не можна видавати себе за іншого ",
    "Impersonate other users" : "Знеособити інших користувачів",
    "By installing the impersonate app of your Nextcloud you enable administrators to impersonate other users on the Nextcloud server. This is especially useful for debugging issues reported by users.\n\nTo impersonate a user an administrator has to simply follow the following four steps:\n\n1. Login as administrator to Nextcloud.\n2. Open users administration interface.\n3. Select the impersonate button on the affected user.\n4. Confirm the impersonation.\n\nThe administrator is then logged-in as the user, to switch back to the regular user account they simply have to press the logout button.\n\n**Note:**\n\n- This app is not compatible with instances that have encryption enabled.\n- While impersonate actions are logged note that actions performed impersonated will be logged as the impersonated user.\n- Impersonating a user is only possible after their first login.\n- You can limit which users/groups can use impersonation in Administration settings > Additional settings." : "Встановивши додаток для імітації Nextcloud, ви надаєте адміністраторам можливість імітувати інших користувачів на сервері Nextcloud. Це особливо корисно для усунення проблем, про які повідомляють користувачі.\n\nЩоб імітувати користувача, адміністратор повинен виконати чотири кроки:\n\n1. Увійти в Nextcloud як адміністратор.\n2. Відкрийте інтерфейс адміністрування користувачів.\n3. Виберіть кнопку «Імітувати» для відповідного користувача.\n4. Підтвердьте імітацію.\n\nПісля цього адміністратор входить в систему як користувач. Щоб повернутися до звичайного облікового запису користувача, йому достатньо натиснути кнопку виходу.\n\n**Примітка:**\n\n- Ця програма несумісна з екземплярами, для яких увімкнено шифрування.\n- Хоча дії підміни реєструються, зверніть увагу, що дії, виконані підміною, будуть зареєстровані як дії підміненого користувача.\n- Підміна користувача можлива тільки після його першого входу в систему.\n- Ви можете обмежити, які користувачі/групи можуть використовувати підміну, в налаштуваннях адміністрування > Додаткові налаштування.",
    "These groups will be able to impersonate users they are allowed to administrate. If you remove all groups, every group administrator will be allowed to impersonate." : "Ці групи зможуть видавати себе за користувачів, яких їм дозволено адмініструвати. Якщо ви вилучите всі групи, кожен адміністратор групи зможе видавати себе за іншого. "
},
"nplurals=4; plural=(n % 1 == 0 && n % 10 == 1 && n % 100 != 11 ? 0 : n % 1 == 0 && n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14) ? 1 : n % 1 == 0 && (n % 10 ==0 || (n % 10 >=5 && n % 10 <=9) || (n % 100 >=11 && n % 100 <=14 )) ? 2: 3);");
