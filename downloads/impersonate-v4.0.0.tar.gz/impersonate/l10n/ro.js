OC.L10N.register(
    "impersonate",
    {
    "Could not impersonate user" : "Nu s-a putut impersona utilizatorul",
    "Are you sure you want to impersonate \"{userId}\"?" : "Ești sigur că dorești să impersonezi \"{userId}\"?",
    "Impersonate user" : "Impersonează utilizator",
    "Impersonate" : "Impersonează",
    "Could not log out, please try again" : "Deconectarea a eșuat, încercați din nou",
    "Logged in as {name} ({uid})" : "Autentificat ca {name} ({uid})",
    "User not found" : "Utilizatorul nu a fost găsit"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
