OC.L10N.register(
    "tasks",
    {
    "Today" : "Ass-a",
    "Week" : "Amalas",
    "All" : "Akk",
    "Current" : "Amiran",
    "Completed" : "Yemmed",
    "Edit" : "Ẓreg",
    "Delete" : "Kkes",
    "Name" : "Nom",
    "Deleted" : "Yettwakkes",
    "Delete permanently" : "Kkes-it i lebda",
    "Cancel" : "Sefsex",
    "Notification" : "Ilɣa",
    "Email" : "Imayl",
    "Go back" : "Tuɣalin",
    "Close" : "Mdel",
    "Tags" : "Tibzimin",
    "Details" : "Talqayt"
},
"nplurals=2; plural=(n != 1);");
