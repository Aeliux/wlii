import { AccountEnvironment } from '.';
export declare const environment: AccountEnvironment;
