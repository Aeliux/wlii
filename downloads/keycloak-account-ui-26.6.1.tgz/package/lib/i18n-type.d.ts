export type TFuncKey = any;
