import type { KeycloakAdminClient } from "../client.js";
import type { WithVersionItemRequestBuilder } from "../generated/admin/api/item/clients/item/index.js";
export type { OIDCClientRepresentation, SAMLClientRepresentation, } from "../generated/models/index.js";
export type ClientRepresentationV2 = import("../generated/models/index.js").OIDCClientRepresentation | import("../generated/models/index.js").SAMLClientRepresentation;
/**
 * Clients v2 API resource.
 * Provides access to the new versioned clients API using the configured realm.
 */
export declare class ClientsV2 {
    #private;
    constructor(client: KeycloakAdminClient);
    /**
     * Get the clients v2 endpoint for the currently configured realm.
     * Returns a fluent API builder for client operations.
     *
     * @returns The clients v2 endpoint
     */
    api(): WithVersionItemRequestBuilder;
}
