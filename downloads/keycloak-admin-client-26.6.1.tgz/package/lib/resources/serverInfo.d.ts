import Resource from "./resource.js";
import type { ServerInfoRepresentation } from "../defs/serverInfoRepesentation.js";
import type KeycloakAdminClient from "../index.js";
import type EffectiveMessageBundleRepresentation from "../defs/effectiveMessageBundleRepresentation.js";
export interface MessageBundleQuery {
    realm: string;
    theme?: string;
    themeType?: string;
    locale?: string;
    source?: boolean;
}
export declare class ServerInfo extends Resource {
    constructor(client: KeycloakAdminClient);
    find: (payload?: {} | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ServerInfoRepresentation>;
    findEffectiveMessageBundles: (payload?: MessageBundleQuery | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<EffectiveMessageBundleRepresentation[]>;
}
