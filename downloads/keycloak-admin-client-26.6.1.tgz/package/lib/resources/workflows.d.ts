import Resource from "./resource.js";
import type { KeycloakAdminClient } from "../client.js";
import WorkflowRepresentation from "../defs/workflowRepresentation.js";
export declare class Workflows extends Resource<{
    realm?: string;
}> {
    constructor(client: KeycloakAdminClient);
    find: (payload?: any, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    findOne: (payload?: ({
        id: string;
        includeId: boolean;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<WorkflowRepresentation | undefined>;
    scheduled: (payload?: ({
        userId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<WorkflowRepresentation[]>;
    update: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: WorkflowRepresentation) => Promise<void>;
    create: (payload?: (WorkflowRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        id: string;
    }>;
    createAsYaml: (payload?: ({
        realm: string;
        yaml: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        id: string;
    }>;
    delById: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
}
