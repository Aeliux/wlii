import type { KeycloakAdminClient } from "../client.js";
import type CertificateRepresentation from "../defs/certificateRepresentation.js";
import type ClientRepresentation from "../defs/clientRepresentation.js";
import type ClientScopeRepresentation from "../defs/clientScopeRepresentation.js";
import type CredentialRepresentation from "../defs/credentialRepresentation.js";
import type GlobalRequestResult from "../defs/globalRequestResult.js";
import type KeyStoreConfig from "../defs/keystoreConfig.js";
import type { ManagementPermissionReference } from "../defs/managementPermissionReference.js";
import type MappingsRepresentation from "../defs/mappingsRepresentation.js";
import type PolicyEvaluationResponse from "../defs/policyEvaluationResponse.js";
import type PolicyProviderRepresentation from "../defs/policyProviderRepresentation.js";
import type PolicyRepresentation from "../defs/policyRepresentation.js";
import type ProtocolMapperRepresentation from "../defs/protocolMapperRepresentation.js";
import type ResourceEvaluation from "../defs/resourceEvaluation.js";
import type ResourceRepresentation from "../defs/resourceRepresentation.js";
import type ResourceServerRepresentation from "../defs/resourceServerRepresentation.js";
import type RoleRepresentation from "../defs/roleRepresentation.js";
import type ScopeRepresentation from "../defs/scopeRepresentation.js";
import type UserRepresentation from "../defs/userRepresentation.js";
import type UserSessionRepresentation from "../defs/userSessionRepresentation.js";
import Resource from "./resource.js";
export interface PaginatedQuery {
    first?: number;
    max?: number;
}
export interface ClientQuery extends PaginatedQuery {
    clientId?: string;
    viewableOnly?: boolean;
    search?: boolean;
    q?: string;
}
export interface ResourceQuery extends PaginatedQuery {
    id?: string;
    name?: string;
    type?: string;
    owner?: string;
    uri?: string;
    deep?: boolean;
}
export interface PolicyQuery extends PaginatedQuery {
    id?: string;
    name?: string;
    type?: string;
    resource?: string;
    scope?: string;
    permission?: string;
    owner?: string;
    fields?: string;
}
export declare class Clients extends Resource<{
    realm?: string;
}> {
    #private;
    find: (payload?: (ClientQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ClientRepresentation[]>;
    create: (payload?: (ClientRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        id: string;
    }>;
    /**
     * Single client
     */
    findOne: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ClientRepresentation | undefined>;
    update: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ClientRepresentation) => Promise<void>;
    del: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * Client roles
     */
    createRole: (payload?: (RoleRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        roleName: string;
    }>;
    listRoles: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    findRole: (payload?: ({
        id: string;
        roleName: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation | null>;
    updateRole: (query: {
        id: string;
        roleName: string;
    } & {
        realm?: string;
    }, payload: RoleRepresentation) => Promise<void>;
    delRole: (payload?: ({
        id: string;
        roleName: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    findUsersWithRole: (payload?: ({
        id: string;
        roleName: string;
        briefRepresentation?: boolean;
        first?: number;
        max?: number;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserRepresentation[]>;
    /**
     * Service account user
     */
    getServiceAccountUser: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserRepresentation>;
    /**
     * Client secret
     */
    generateNewClientSecret: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<CredentialRepresentation>;
    invalidateSecret: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    generateRegistrationAccessToken: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        registrationAccessToken: string;
    }>;
    getClientSecret: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<CredentialRepresentation>;
    /**
     * Client Scopes
     */
    listDefaultClientScopes: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ClientScopeRepresentation[]>;
    addDefaultClientScope: (payload?: ({
        id: string;
        clientScopeId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    delDefaultClientScope: (payload?: ({
        id: string;
        clientScopeId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    listOptionalClientScopes: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ClientScopeRepresentation[]>;
    addOptionalClientScope: (payload?: ({
        id: string;
        clientScopeId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    delOptionalClientScope: (payload?: ({
        id: string;
        clientScopeId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * Protocol Mappers
     */
    addMultipleProtocolMappers: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ProtocolMapperRepresentation[]) => Promise<void>;
    addProtocolMapper: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ProtocolMapperRepresentation) => Promise<void>;
    listProtocolMappers: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ProtocolMapperRepresentation[]>;
    findProtocolMapperById: (payload?: ({
        id: string;
        mapperId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ProtocolMapperRepresentation>;
    findProtocolMappersByProtocol: (payload?: ({
        id: string;
        protocol: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ProtocolMapperRepresentation[]>;
    updateProtocolMapper: (query: {
        id: string;
        mapperId: string;
    } & {
        realm?: string;
    }, payload: ProtocolMapperRepresentation) => Promise<void>;
    delProtocolMapper: (payload?: ({
        id: string;
        mapperId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * Scope Mappings
     */
    listScopeMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<MappingsRepresentation>;
    addClientScopeMappings: (query: {
        id: string;
        client: string;
    } & {
        realm?: string;
    }, payload: RoleRepresentation[]) => Promise<void>;
    listClientScopeMappings: (payload?: ({
        id: string;
        client: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    listAvailableClientScopeMappings: (payload?: ({
        id: string;
        client: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    listCompositeClientScopeMappings: (payload?: ({
        id: string;
        client: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    delClientScopeMappings: (query: {
        id: string;
        client: string;
    } & {
        realm?: string;
    }, payload: RoleRepresentation[]) => Promise<void>;
    evaluatePermission: (payload?: ({
        id: string;
        roleContainer: string;
        type: "granted" | "not-granted";
        scope: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    evaluateListProtocolMapper: (payload?: ({
        id: string;
        scope: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ProtocolMapperRepresentation[]>;
    evaluateGenerateAccessToken: (payload?: ({
        id: string;
        scope: string;
        userId: string;
        audience: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<Record<string, unknown>>;
    evaluateGenerateUserInfo: (payload?: ({
        id: string;
        scope: string;
        userId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<Record<string, unknown>>;
    evaluateGenerateIdToken: (payload?: ({
        id: string;
        scope: string;
        userId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<Record<string, unknown>>;
    addRealmScopeMappings: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: RoleRepresentation[]) => Promise<void>;
    listRealmScopeMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    listAvailableRealmScopeMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    listCompositeRealmScopeMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    delRealmScopeMappings: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: RoleRepresentation[]) => Promise<void>;
    /**
     * Sessions
     */
    listSessions: (payload?: ({
        id: string;
        first?: number;
        max?: number;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserSessionRepresentation[]>;
    listOfflineSessions: (payload?: ({
        id: string;
        first?: number;
        max?: number;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserSessionRepresentation[]>;
    getSessionCount: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        count: number;
    }>;
    /**
     * Resource
     */
    getResourceServer: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ResourceServerRepresentation>;
    updateResourceServer: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ResourceServerRepresentation) => Promise<void>;
    listResources: (payload?: (ResourceQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ResourceRepresentation[]>;
    createResource: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ResourceRepresentation) => Promise<ResourceRepresentation>;
    getResource: (payload?: ({
        id: string;
        resourceId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ResourceRepresentation>;
    updateResource: (query: {
        id: string;
        resourceId: string;
    } & {
        realm?: string;
    }, payload: ResourceRepresentation) => Promise<void>;
    delResource: (payload?: ({
        id: string;
        resourceId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    importResource: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ResourceServerRepresentation) => Promise<any>;
    exportResource: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ResourceServerRepresentation>;
    evaluateResource: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ResourceEvaluation) => Promise<PolicyEvaluationResponse>;
    /**
     * Policy
     */
    listPolicies: (payload?: (PolicyQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<"" | PolicyRepresentation[]>;
    findPolicyByName: (payload?: ({
        id: string;
        name: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<PolicyRepresentation>;
    updatePolicy: (query: {
        id: string;
        type: string;
        policyId: string;
    } & {
        realm?: string;
    }, payload: PolicyRepresentation) => Promise<void>;
    createPolicy: (query: {
        id: string;
        type: string;
    } & {
        realm?: string;
    }, payload: PolicyRepresentation) => Promise<PolicyRepresentation>;
    findOnePolicyWithType: (payload?: ({
        id: string;
        type: string;
        policyId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    findOnePolicy: (payload?: ({
        id: string;
        policyId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    listDependentPolicies: (payload?: ({
        id: string;
        policyId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<PolicyRepresentation[]>;
    delPolicy: (payload?: ({
        id: string;
        policyId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    listPolicyProviders: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<PolicyProviderRepresentation[]>;
    createOrUpdatePolicy(payload: {
        id: string;
        policyName: string;
        policy: PolicyRepresentation;
    }): Promise<PolicyRepresentation>;
    /**
     * Scopes
     */
    listAllScopes: (payload?: ({
        id: string;
        name?: string;
        deep?: boolean;
    } & PaginatedQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ScopeRepresentation[]>;
    listAllResourcesByScope: (payload?: ({
        id: string;
        scopeId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ResourceRepresentation[]>;
    listAllPermissionsByScope: (payload?: ({
        id: string;
        scopeId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<PolicyRepresentation[]>;
    listPermissionsByResource: (payload?: ({
        id: string;
        resourceId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<PolicyRepresentation[]>;
    listScopesByResource: (payload?: ({
        id: string;
        resourceName: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        id: string;
        name: string;
    }[]>;
    listPermissionScope: (payload?: ({
        id: string;
        policyId?: string;
        name?: string;
        resource?: string;
    } & PaginatedQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<PolicyRepresentation[]>;
    createAuthorizationScope: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ScopeRepresentation) => Promise<any>;
    updateAuthorizationScope: (query: {
        id: string;
        scopeId: string;
    } & {
        realm?: string;
    }, payload: ScopeRepresentation) => Promise<any>;
    getAuthorizationScope: (payload?: ({
        id: string;
        scopeId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ScopeRepresentation>;
    delAuthorizationScope: (payload?: ({
        id: string;
        scopeId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * Permissions
     */
    findPermissions: (payload?: ({
        id: string;
        name?: string;
        resource?: string;
        scope?: string;
    } & PaginatedQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<PolicyRepresentation[]>;
    createPermission: (query: {
        id: string;
        type: string;
    } & {
        realm?: string;
    }, payload: PolicyRepresentation) => Promise<PolicyRepresentation>;
    updatePermission: (query: {
        id: string;
        type: string;
        permissionId: string;
    } & {
        realm?: string;
    }, payload: PolicyRepresentation) => Promise<void>;
    delPermission: (payload?: ({
        id: string;
        type: string;
        permissionId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    findOnePermission: (payload?: ({
        id: string;
        type: string;
        permissionId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<PolicyRepresentation | undefined>;
    getAssociatedScopes: (payload?: ({
        id: string;
        permissionId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        id: string;
        name: string;
    }[]>;
    getAssociatedResources: (payload?: ({
        id: string;
        permissionId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        _id: string;
        name: string;
    }[]>;
    getAssociatedPolicies: (payload?: ({
        id: string;
        permissionId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<PolicyRepresentation[]>;
    getOfflineSessionCount: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        count: number;
    }>;
    getInstallationProviders: (payload?: ({
        id: string;
        providerId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<string>;
    pushRevocation: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<GlobalRequestResult>;
    addClusterNode: (payload?: ({
        id: string;
        node: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    deleteClusterNode: (payload?: ({
        id: string;
        node: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    testNodesAvailable: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<GlobalRequestResult>;
    getKeyInfo: (payload?: ({
        id: string;
        attr: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<CertificateRepresentation>;
    generateKey: (payload?: ({
        id: string;
        attr: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<CertificateRepresentation>;
    downloadKey: (query: {
        id: string;
        attr: string;
    } & {
        realm?: string;
    }, payload: KeyStoreConfig) => Promise<ArrayBuffer>;
    generateAndDownloadKey: (query: {
        id: string;
        attr: string;
    } & {
        realm?: string;
    }, payload: KeyStoreConfig) => Promise<ArrayBuffer>;
    uploadKey: (query: {
        id: string;
        attr: string;
    } & {
        realm?: string;
    }, payload: FormData) => Promise<any>;
    uploadCertificate: (query: {
        id: string;
        attr: string;
    } & {
        realm?: string;
    }, payload: FormData) => Promise<any>;
    updateFineGrainPermission: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ManagementPermissionReference) => Promise<ManagementPermissionReference>;
    listFineGrainPermissions: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ManagementPermissionReference>;
    constructor(client: KeycloakAdminClient);
    /**
     * Get the clients v2 API endpoint for the currently configured realm.
     * Returns a fluent API builder for client operations using the new versioned API.
     *
     * Note: This API is experimental and must be explicitly enabled by setting
     * `enableExperimentalApis: true` in the client configuration.
     *
     * @example
     * ```typescript
     * // Enable experimental APIs in client configuration
     * const kcAdminClient = new KeycloakAdminClient({
     *   baseUrl: "http://localhost:8080",
     *   enableExperimentalApis: true,
     * });
     *
     * // List all clients
     * const clients = await kcAdminClient.clients.v2().get();
     *
     * // Get a single client by clientId
     * const client = await kcAdminClient.clients.v2().byId("my-client").get();
     *
     * // Create a new client
     * await kcAdminClient.clients.v2().post({
     *   clientId: "my-client",
     *   protocol: "openid-connect",
     *   enabled: true,
     * });
     *
     * // Update a client
     * await kcAdminClient.clients.v2().byId("my-client").put({
     *   clientId: "my-client",
     *   protocol: "openid-connect",
     *   description: "Updated description",
     * });
     *
     * // Delete a client
     * await kcAdminClient.clients.v2().byId("my-client").delete();
     * ```
     *
     * @returns A promise that resolves to the clients v2 endpoint
     * @throws Error if experimental APIs are not enabled
     */
    v2(): import("../generated/admin/api/item/clients/item/index.js").WithVersionItemRequestBuilder;
    /**
     * Find single protocol mapper by name.
     */
    findProtocolMapperByName(payload: {
        realm?: string;
        id: string;
        name: string;
    }): Promise<ProtocolMapperRepresentation | undefined>;
}
