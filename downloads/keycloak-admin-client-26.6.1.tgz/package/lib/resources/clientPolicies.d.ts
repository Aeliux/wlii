import Resource from "./resource.js";
import type { KeycloakAdminClient } from "../client.js";
import type ClientProfilesRepresentation from "../defs/clientProfilesRepresentation.js";
import type ClientPoliciesRepresentation from "../defs/clientPoliciesRepresentation.js";
/**
 * https://www.keycloak.org/docs-api/15.0/rest-api/#_client_registration_policy_resource
 */
export declare class ClientPolicies extends Resource<{
    realm?: string;
}> {
    constructor(client: KeycloakAdminClient);
    listProfiles: (payload?: ({
        includeGlobalProfiles?: boolean;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ClientProfilesRepresentation>;
    createProfiles: (payload?: (ClientProfilesRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    listPolicies: (payload?: ({
        includeGlobalPolicies?: boolean;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ClientPoliciesRepresentation>;
    updatePolicy: (payload?: (ClientPoliciesRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
}
