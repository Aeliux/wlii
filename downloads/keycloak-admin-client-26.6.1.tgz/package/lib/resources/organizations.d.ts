import type { KeycloakAdminClient } from "../client.js";
import IdentityProviderRepresentation from "../defs/identityProviderRepresentation.js";
import type OrganizationRepresentation from "../defs/organizationRepresentation.js";
import type OrganizationInvitationRepresentation from "../defs/organizationInvitationRepresentation.js";
import UserRepresentation from "../defs/userRepresentation.js";
import Resource from "./resource.js";
import { Groups } from "./groups.js";
import OrganizationMemberRepresentation from "../defs/organizationMemberRepresentation.js";
interface PaginatedQuery {
    first?: number;
    max?: number;
    search?: string;
}
export interface OrganizationQuery extends PaginatedQuery {
    q?: string;
    exact?: boolean;
}
interface MemberQuery extends PaginatedQuery {
    orgId: string;
    membershipType?: string;
}
interface InvitationQuery extends PaginatedQuery {
    orgId: string;
    status?: string;
    email?: string;
    search?: string;
    firstName?: string;
    lastName?: string;
}
export declare class Organizations extends Resource<{
    realm?: string;
}> {
    #private;
    constructor(client: KeycloakAdminClient);
    find: (payload?: (OrganizationQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<OrganizationRepresentation[]>;
    findOne: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<OrganizationRepresentation>;
    create: (payload?: (OrganizationRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        id: string;
    }>;
    delById: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    updateById: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: OrganizationRepresentation) => Promise<void>;
    listMembers: (payload?: (MemberQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserRepresentation[]>;
    addMember: (payload?: ({
        orgId: string;
        userId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<string>;
    delMember: (payload?: ({
        orgId: string;
        userId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<string>;
    getMember: (payload?: ({
        orgId: string;
        userId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<OrganizationMemberRepresentation>;
    memberOrganizations: (payload?: ({
        userId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<OrganizationRepresentation[]>;
    invite: (query: {
        orgId: string;
    } & {
        realm?: string;
    }, payload: FormData) => Promise<any>;
    inviteExistingUser: (query: {
        orgId: string;
    } & {
        realm?: string;
    }, payload: FormData) => Promise<any>;
    listIdentityProviders: (payload?: ({
        orgId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<IdentityProviderRepresentation[]>;
    linkIdp: (payload?: ({
        orgId: string;
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<string>;
    unLinkIdp: (payload?: ({
        orgId: string;
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<string>;
    listInvitations: (payload?: (InvitationQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<OrganizationInvitationRepresentation[]>;
    findInvitation: (payload?: ({
        orgId: string;
        invitationId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<OrganizationInvitationRepresentation>;
    resendInvitation: (payload?: ({
        orgId: string;
        invitationId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    deleteInvitation: (payload?: ({
        orgId: string;
        invitationId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    groups: (orgId: string) => Groups;
}
export {};
