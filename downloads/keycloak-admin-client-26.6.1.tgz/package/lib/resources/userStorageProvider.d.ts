import type { KeycloakAdminClient } from "../client.js";
import type SynchronizationResultRepresentation from "../defs/synchronizationResultRepresentation.js";
import Resource from "./resource.js";
type ActionType = "triggerFullSync" | "triggerChangedUsersSync";
export type DirectionType = "fedToKeycloak" | "keycloakToFed";
type NameResponse = {
    id: string;
    name: string;
};
export declare class UserStorageProvider extends Resource<{
    realm?: string;
}> {
    name: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<NameResponse>;
    removeImportedUsers: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    sync: (payload?: ({
        id: string;
        action?: ActionType;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<SynchronizationResultRepresentation>;
    unlinkUsers: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    mappersSync: (payload?: ({
        id: string;
        parentId: string;
        direction?: DirectionType;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<SynchronizationResultRepresentation>;
    constructor(client: KeycloakAdminClient);
}
export {};
