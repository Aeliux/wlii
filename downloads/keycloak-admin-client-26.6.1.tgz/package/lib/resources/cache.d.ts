import Resource from "./resource.js";
import type { KeycloakAdminClient } from "../client.js";
export declare class Cache extends Resource<{
    realm?: string;
}> {
    clearUserCache: (payload?: {
        realm?: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    clearKeysCache: (payload?: {
        realm?: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    clearCrlCache: (payload?: {
        realm?: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    clearRealmCache: (payload?: {
        realm?: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    constructor(client: KeycloakAdminClient);
}
