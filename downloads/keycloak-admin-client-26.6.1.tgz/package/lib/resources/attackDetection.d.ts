import Resource from "./resource.js";
import type KeycloakAdminClient from "../index.js";
export declare class AttackDetection extends Resource<{
    realm?: string;
}> {
    findOne: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<Record<string, any> | undefined>;
    del: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    delAll: (payload?: {
        realm?: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    constructor(client: KeycloakAdminClient);
}
