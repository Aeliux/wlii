import Resource from "./resource.js";
import type AdminEventRepresentation from "../defs/adminEventRepresentation.js";
import type RealmRepresentation from "../defs/realmRepresentation.js";
import type { PartialImportRealmRepresentation, PartialImportResponse } from "../defs/realmRepresentation.js";
import type EventRepresentation from "../defs/eventRepresentation.js";
import type EventType from "../defs/eventTypes.js";
import type KeysMetadataRepresentation from "../defs/keyMetadataRepresentation.js";
import type ClientInitialAccessPresentation from "../defs/clientInitialAccessPresentation.js";
import type TestLdapConnectionRepresentation from "../defs/testLdapConnection.js";
import type { KeycloakAdminClient } from "../client.js";
import type { RealmEventsConfigRepresentation } from "../defs/realmEventsConfigRepresentation.js";
import type GlobalRequestResult from "../defs/globalRequestResult.js";
import type GroupRepresentation from "../defs/groupRepresentation.js";
import type { ManagementPermissionReference } from "../defs/managementPermissionReference.js";
import type ComponentTypeRepresentation from "../defs/componentTypeRepresentation.js";
import type { ClientSessionStat } from "../defs/clientSessionStat.js";
export declare class Realms extends Resource {
    /**
     * Realm
     * https://www.keycloak.org/docs-api/11.0/rest-api/#_realms_admin_resource
     */
    find: (payload?: {
        briefRepresentation?: boolean;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RealmRepresentation[]>;
    create: (payload?: RealmRepresentation | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        realmName: string;
    }>;
    findOne: (payload?: {
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RealmRepresentation | undefined>;
    update: (query: {
        realm: string;
    }, payload: RealmRepresentation) => Promise<void>;
    del: (payload?: {
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    partialImport: (payload?: {
        realm: string;
        rep: PartialImportRealmRepresentation;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<PartialImportResponse>;
    export: (payload?: {
        realm: string;
        exportClients?: boolean;
        exportGroupsAndRoles?: boolean;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RealmRepresentation>;
    getDefaultGroups: (payload?: {
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<GroupRepresentation[]>;
    addDefaultGroup: (payload?: {
        realm: string;
        id: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    removeDefaultGroup: (payload?: {
        realm: string;
        id: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    getGroupByPath: (payload?: {
        path: string;
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<GroupRepresentation>;
    /**
     * Get events Returns all events, or filters them based on URL query parameters listed here
     */
    findEvents: (payload?: {
        realm: string;
        client?: string;
        dateFrom?: string;
        dateTo?: string;
        first?: number;
        ipAddress?: string;
        max?: number;
        type?: EventType | EventType[];
        user?: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<EventRepresentation[]>;
    getConfigEvents: (payload?: {
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RealmEventsConfigRepresentation>;
    updateConfigEvents: (query: {
        realm: string;
    }, payload: RealmEventsConfigRepresentation) => Promise<void>;
    clearEvents: (payload?: {
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    clearAdminEvents: (payload?: {
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    getClientRegistrationPolicyProviders: (payload?: {
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ComponentTypeRepresentation[]>;
    getClientsInitialAccess: (payload?: {
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ClientInitialAccessPresentation[]>;
    createClientsInitialAccess: (query: {
        realm: string;
    }, payload: {
        count?: number;
        expiration?: number;
    }) => Promise<ClientInitialAccessPresentation>;
    delClientsInitialAccess: (payload?: {
        realm: string;
        id: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * Remove a specific user session.
     */
    removeSession: (payload?: {
        realm: string;
        sessionId: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * Get admin events Returns all admin events, or filters events based on URL query parameters listed here
     */
    findAdminEvents: (payload?: {
        realm: string;
        authClient?: string;
        authIpAddress?: string;
        authRealm?: string;
        authUser?: string;
        dateFrom?: Date;
        dateTo?: Date;
        first?: number;
        max?: number;
        operationTypes?: string;
        resourcePath?: string;
        resourceTypes?: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<AdminEventRepresentation[]>;
    /**
     * Users management permissions
     */
    getUsersManagementPermissions: (payload?: {
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ManagementPermissionReference>;
    updateUsersManagementPermissions: (payload?: {
        realm: string;
        enabled: boolean;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ManagementPermissionReference>;
    /**
     * Sessions
     */
    getClientSessionStats: (payload?: {
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ClientSessionStat[]>;
    logoutAll: (payload?: {
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    deleteSession: (payload?: {
        realm: string;
        session: string;
        isOffline: boolean;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    pushRevocation: (payload?: {
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<GlobalRequestResult>;
    getKeys: (payload?: {
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<KeysMetadataRepresentation>;
    testLDAPConnection: (query: {
        realm: string;
    }, payload: TestLdapConnectionRepresentation) => Promise<any>;
    testSMTPConnection: (query: {
        realm: string;
    }, payload: Record<string, string | number>) => Promise<any>;
    ldapServerCapabilities: (query: {
        realm: string;
    }, payload: TestLdapConnectionRepresentation) => Promise<any>;
    getRealmSpecificLocales: (payload?: {
        realm: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<string[]>;
    getRealmLocalizationTexts: (payload?: {
        realm: string;
        selectedLocale: string;
        first?: number;
        max?: number;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<Record<string, string>>;
    addLocalization: (query: {
        realm: string;
        selectedLocale: string;
        key: string;
    }, payload: string) => Promise<void>;
    deleteRealmLocalizationTexts: (payload?: {
        realm: string;
        selectedLocale: string;
        key?: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    constructor(client: KeycloakAdminClient);
}
