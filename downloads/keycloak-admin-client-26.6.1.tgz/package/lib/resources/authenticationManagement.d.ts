import Resource from "./resource.js";
import type RequiredActionProviderRepresentation from "../defs/requiredActionProviderRepresentation.js";
import type { KeycloakAdminClient } from "../client.js";
import type AuthenticationExecutionInfoRepresentation from "../defs/authenticationExecutionInfoRepresentation.js";
import type AuthenticationFlowRepresentation from "../defs/authenticationFlowRepresentation.js";
import type AuthenticatorConfigRepresentation from "../defs/authenticatorConfigRepresentation.js";
import type { AuthenticationProviderRepresentation } from "../defs/authenticatorConfigRepresentation.js";
import type AuthenticatorConfigInfoRepresentation from "../defs/authenticatorConfigInfoRepresentation.js";
import type RequiredActionProviderSimpleRepresentation from "../defs/requiredActionProviderSimpleRepresentation.js";
import type RequiredActionConfigInfoRepresentation from "../defs/requiredActionConfigInfoRepresentation.js";
import type RequiredActionConfigRepresentation from "../defs/requiredActionConfigRepresentation.js";
export declare class AuthenticationManagement extends Resource<{
    realm?: string;
}> {
    /**
     * Authentication Management
     * https://www.keycloak.org/docs-api/8.0/rest-api/index.html#_authentication_management_resource
     */
    registerRequiredAction: (payload?: (Record<string, any> & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    getRequiredActions: (payload?: (void & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RequiredActionProviderRepresentation[]>;
    getRequiredActionForAlias: (payload?: ({
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    getClientAuthenticatorProviders: (payload?: (void & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<AuthenticationProviderRepresentation[]>;
    getAuthenticatorProviders: (payload?: (void & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<AuthenticationProviderRepresentation[]>;
    getFormActionProviders: (payload?: (void & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<AuthenticationProviderRepresentation[]>;
    updateRequiredAction: (query: {
        alias: string;
    } & {
        realm?: string;
    }, payload: RequiredActionProviderRepresentation) => Promise<void>;
    deleteRequiredAction: (payload?: ({
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    lowerRequiredActionPriority: (payload?: ({
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    raiseRequiredActionPriority: (payload?: ({
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    getUnregisteredRequiredActions: (payload?: (void & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RequiredActionProviderSimpleRepresentation[]>;
    getFlows: (payload?: {
        realm?: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<AuthenticationFlowRepresentation[]>;
    getFlow: (payload?: ({
        flowId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<AuthenticationFlowRepresentation>;
    getFormProviders: (payload?: (void & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<AuthenticationProviderRepresentation[]>;
    createFlow: (payload?: (AuthenticationFlowRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<AuthenticationFlowRepresentation>;
    copyFlow: (payload?: ({
        flow: string;
        newName: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    deleteFlow: (payload?: ({
        flowId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    updateFlow: (query: {
        flowId: string;
    } & {
        realm?: string;
    }, payload: AuthenticationFlowRepresentation) => Promise<any>;
    getExecutions: (payload?: ({
        flow: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<AuthenticationExecutionInfoRepresentation[]>;
    addExecution: (query: {
        flow: string;
    } & {
        realm?: string;
    }, payload: AuthenticationExecutionInfoRepresentation) => Promise<any>;
    addExecutionToFlow: (payload?: ({
        flow: string;
        provider: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<AuthenticationExecutionInfoRepresentation>;
    addFlowToFlow: (payload?: ({
        flow: string;
        alias: string;
        type: string;
        provider: string;
        description: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<AuthenticationFlowRepresentation>;
    updateExecution: (query: {
        flow: string;
    } & {
        realm?: string;
    }, payload: AuthenticationExecutionInfoRepresentation) => Promise<any>;
    delExecution: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    lowerPriorityExecution: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    raisePriorityExecution: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    getRequiredActionConfigDescription: (payload?: ({
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RequiredActionConfigInfoRepresentation>;
    getRequiredActionConfig: (payload?: ({
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RequiredActionConfigRepresentation>;
    removeRequiredActionConfig: (payload?: ({
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    updateRequiredActionConfig: (query: {
        alias: string;
    } & {
        realm?: string;
    }, payload: RequiredActionConfigRepresentation) => Promise<void>;
    getConfigDescription: (payload?: ({
        providerId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<AuthenticatorConfigInfoRepresentation>;
    createConfig: (payload?: (AuthenticatorConfigRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<AuthenticatorConfigRepresentation>;
    updateConfig: (payload?: (AuthenticatorConfigRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    getConfig: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<AuthenticatorConfigRepresentation>;
    delConfig: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    constructor(client: KeycloakAdminClient);
}
