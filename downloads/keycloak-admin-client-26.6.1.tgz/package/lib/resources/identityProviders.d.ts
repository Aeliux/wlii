import type { KeycloakAdminClient } from "../client.js";
import type IdentityProviderMapperRepresentation from "../defs/identityProviderMapperRepresentation.js";
import type { IdentityProviderMapperTypeRepresentation } from "../defs/identityProviderMapperTypeRepresentation.js";
import type IdentityProviderRepresentation from "../defs/identityProviderRepresentation.js";
import type { ManagementPermissionReference } from "../defs/managementPermissionReference.js";
import type CertificateRepresentation from "../defs/certificateRepresentation.js";
import Resource from "./resource.js";
export interface PaginatedQuery {
    first?: number;
    max?: number;
}
export interface IdentityProvidersQuery extends PaginatedQuery {
    search?: string;
    realmOnly?: boolean;
    type?: string;
    capability?: string;
}
export declare class IdentityProviders extends Resource<{
    realm?: string;
}> {
    /**
     * Identity provider
     * https://www.keycloak.org/docs-api/11.0/rest-api/#_identity_providers_resource
     */
    find: (payload?: (IdentityProvidersQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<IdentityProviderRepresentation[]>;
    create: (payload?: (IdentityProviderRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        id: string;
    }>;
    findOne: (payload?: ({
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<IdentityProviderRepresentation | undefined>;
    uploadCertificate: (query: {
        realm?: string;
    }, payload: FormData) => Promise<CertificateRepresentation>;
    update: (query: {
        alias: string;
    } & {
        realm?: string;
    }, payload: IdentityProviderRepresentation) => Promise<void>;
    del: (payload?: ({
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    findFactory: (payload?: ({
        providerId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<any>;
    findMappers: (payload?: ({
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<IdentityProviderMapperRepresentation[]>;
    findOneMapper: (payload?: ({
        alias: string;
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<IdentityProviderMapperRepresentation | undefined>;
    createMapper: (payload?: ({
        alias: string;
        identityProviderMapper: IdentityProviderMapperRepresentation;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        id: string;
    }>;
    updateMapper: (query: {
        alias: string;
        id: string;
    } & {
        realm?: string;
    }, payload: IdentityProviderMapperRepresentation) => Promise<void>;
    delMapper: (payload?: ({
        alias: string;
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    findMapperTypes: (payload?: ({
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<Record<string, IdentityProviderMapperTypeRepresentation>>;
    importFromUrl: (payload?: ((FormData | {
        fromUrl: string;
        providerId: string;
    }) & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<Record<string, string>>;
    updatePermission: (query: {
        alias: string;
    } & {
        realm?: string;
    }, payload: ManagementPermissionReference) => Promise<ManagementPermissionReference>;
    listPermissions: (payload?: ({
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ManagementPermissionReference>;
    reloadKeys: (payload?: ({
        alias: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<boolean>;
    constructor(client: KeycloakAdminClient);
}
