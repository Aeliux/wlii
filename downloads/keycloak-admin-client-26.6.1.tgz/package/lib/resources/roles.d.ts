import Resource from "./resource.js";
import type RoleRepresentation from "../defs/roleRepresentation.js";
import type UserRepresentation from "../defs/userRepresentation.js";
import type { KeycloakAdminClient } from "../client.js";
import type { ManagementPermissionReference } from "../defs/managementPermissionReference.js";
export interface RoleQuery {
    first?: number;
    max?: number;
    search?: string;
    briefRepresentation?: boolean;
}
export declare class Roles extends Resource<{
    realm?: string;
}> {
    /**
     * Realm roles
     */
    find: (payload?: (RoleQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    create: (payload?: (RoleRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        roleName: string;
    }>;
    /**
     * Roles by name
     */
    findOneByName: (payload?: ({
        name: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation | undefined>;
    updateByName: (query: {
        name: string;
    } & {
        realm?: string;
    }, payload: RoleRepresentation) => Promise<void>;
    delByName: (payload?: ({
        name: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    findUsersWithRole: (payload?: ({
        name: string;
        briefRepresentation?: boolean;
        first?: number;
        max?: number;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserRepresentation[]>;
    /**
     * Roles by id
     */
    findOneById: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation | undefined>;
    createComposite: (query: {
        roleId: string;
    } & {
        realm?: string;
    }, payload: RoleRepresentation[]) => Promise<void>;
    getCompositeRoles: (payload?: ({
        id: string;
        search?: string;
        first?: number;
        max?: number;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    getCompositeRolesForRealm: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    getCompositeRolesForClient: (payload?: ({
        id: string;
        clientId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    delCompositeRoles: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: RoleRepresentation[]) => Promise<void>;
    updateById: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: RoleRepresentation) => Promise<void>;
    delById: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * Authorization permissions
     */
    updatePermission: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ManagementPermissionReference) => Promise<ManagementPermissionReference>;
    listPermissions: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ManagementPermissionReference>;
    constructor(client: KeycloakAdminClient);
}
