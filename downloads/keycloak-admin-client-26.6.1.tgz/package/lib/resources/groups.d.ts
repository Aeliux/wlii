import type { KeycloakAdminClient } from "../client.js";
import type { PaginationQuery, SearchQuery } from "./users.js";
import type GroupRepresentation from "../defs/groupRepresentation.js";
import type { ManagementPermissionReference } from "../defs/managementPermissionReference.js";
import type MappingsRepresentation from "../defs/mappingsRepresentation.js";
import type RoleRepresentation from "../defs/roleRepresentation.js";
import type { RoleMappingPayload } from "../defs/roleRepresentation.js";
import type UserRepresentation from "../defs/userRepresentation.js";
import Resource from "./resource.js";
interface Query {
    q?: string;
    search?: string;
    exact?: boolean;
}
interface PaginatedQuery {
    first?: number;
    max?: number;
}
interface SummarizedQuery {
    briefRepresentation?: boolean;
    populateHierarchy?: boolean;
}
export type GroupQuery = Query & PaginatedQuery & SummarizedQuery;
export type SubGroupQuery = Query & PaginatedQuery & SummarizedQuery & {
    parentId: string;
};
export interface GroupCountQuery {
    search?: string;
    top?: boolean;
}
export declare class Groups extends Resource<{
    realm?: string;
}> {
    #private;
    find: (payload?: (Query & PaginatedQuery & SummarizedQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<GroupRepresentation[]>;
    create: (payload?: (GroupRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        id: string;
    }>;
    updateRoot: (payload?: (GroupRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * Single user
     */
    findOne: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<GroupRepresentation | undefined>;
    update: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: GroupRepresentation) => Promise<void>;
    del: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    count: (payload?: (GroupCountQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        count: number;
    }>;
    /**
     * Creates a child group on the specified parent group. If the group already exists, then an error is returned.
     */
    createChildGroup: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: Omit<GroupRepresentation, "id">) => Promise<{
        id: string;
    }>;
    /**
     * Updates a child group on the specified parent group. If the group doesn’t exist, then an error is returned.
     * Can be used to move a group from one parent to another.
     */
    updateChildGroup: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: GroupRepresentation) => Promise<void>;
    /**
     * Finds all subgroups on the specified parent group matching the provided parameters.
     */
    listSubGroups: (payload?: (Query & PaginatedQuery & SummarizedQuery & {
        parentId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<GroupRepresentation[]>;
    /**
     * Members
     */
    listMembers: (payload?: ({
        id: string;
        first?: number;
        max?: number;
        briefRepresentation?: boolean;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserRepresentation[]>;
    /**
     * Role mappings
     * https://www.keycloak.org/docs-api/11.0/rest-api/#_role_mapper_resource
     */
    listRoleMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<MappingsRepresentation>;
    addRealmRoleMappings: (payload?: ({
        id: string;
        roles: RoleMappingPayload[];
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    listRealmRoleMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    delRealmRoleMappings: (payload?: ({
        id: string;
        roles: RoleMappingPayload[];
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    listAvailableRealmRoleMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    listCompositeRealmRoleMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    /**
     * Client role mappings
     * https://www.keycloak.org/docs-api/11.0/rest-api/#_client_role_mappings_resource
     */
    listClientRoleMappings: (payload?: ({
        id: string;
        clientUniqueId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    listOrgGroups: (payload?: ({
        id: string;
        briefRepresentation?: boolean;
    } & PaginationQuery & SearchQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<GroupRepresentation[]>;
    addClientRoleMappings: (payload?: ({
        id: string;
        clientUniqueId: string;
        roles: RoleMappingPayload[];
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    delClientRoleMappings: (payload?: ({
        id: string;
        clientUniqueId: string;
        roles: RoleMappingPayload[];
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    listAvailableClientRoleMappings: (payload?: ({
        id: string;
        clientUniqueId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    listCompositeClientRoleMappings: (payload?: ({
        id: string;
        clientUniqueId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    /**
     * Authorization permissions
     */
    updatePermission: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ManagementPermissionReference) => Promise<ManagementPermissionReference>;
    listPermissions: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ManagementPermissionReference>;
    addMemberToOrgGroup: (payload?: ({
        groupId: string;
        userId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    removeMemberFromOrgGroup: (payload?: ({
        groupId: string;
        userId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    getOrgId(): string | undefined;
    isOrgGroups(): boolean;
    constructor(client: KeycloakAdminClient, orgId?: string);
}
export {};
