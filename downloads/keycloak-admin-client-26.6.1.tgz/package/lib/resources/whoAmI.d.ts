import type WhoAmIRepresentation from "../defs/whoAmIRepresentation.js";
import type KeycloakAdminClient from "../index.js";
import Resource from "./resource.js";
export declare class WhoAmI extends Resource<{
    realm?: string;
}> {
    constructor(client: KeycloakAdminClient);
    find: (payload?: ({
        currentRealm: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<WhoAmIRepresentation>;
}
