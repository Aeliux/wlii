import type { KeycloakAdminClient } from "../client.js";
type Method = "GET" | "POST" | "PUT" | "DELETE";
export interface RequestArgs {
    method: Method;
    path?: string;
    urlParamKeys?: string[];
    queryParamKeys?: string[];
    keyTransform?: Record<string, string>;
    catchNotFound?: boolean;
    payloadKey?: string;
    returnResourceIdInLocationHeader?: {
        field: string;
    };
    /**
     * Keys to be ignored, meaning that they will not be filtered out of the request payload even if they are a part of `urlParamKeys` or `queryParamKeys`,
     */
    ignoredKeys?: string[];
    headers?: [string, string][] | Record<string, string> | Headers;
}
export declare class Agent {
    #private;
    constructor({ client, path, getUrlParams, getBaseUrl, }: {
        client: KeycloakAdminClient;
        path?: string;
        getUrlParams?: () => Record<string, any>;
        getBaseUrl?: () => string;
    });
    request({ method, path, urlParamKeys, queryParamKeys, catchNotFound, keyTransform, payloadKey, returnResourceIdInLocationHeader, ignoredKeys, headers, }: RequestArgs): (payload?: any, options?: Pick<RequestArgs, "catchNotFound">) => Promise<any>;
    updateRequest({ method, path, urlParamKeys, queryParamKeys, catchNotFound, keyTransform, payloadKey, returnResourceIdInLocationHeader, headers, }: RequestArgs): (query?: any, payload?: any) => Promise<any>;
}
export {};
