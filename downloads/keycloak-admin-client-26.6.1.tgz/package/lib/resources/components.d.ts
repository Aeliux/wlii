import Resource from "./resource.js";
import type ComponentRepresentation from "../defs/componentRepresentation.js";
import type ComponentTypeRepresentation from "../defs/componentTypeRepresentation.js";
import type { KeycloakAdminClient } from "../client.js";
export interface ComponentQuery {
    name?: string;
    parent?: string;
    type?: string;
    providerId?: string;
}
export declare class Components extends Resource<{
    realm?: string;
}> {
    /**
     * components
     * https://www.keycloak.org/docs-api/11.0/rest-api/#_component_resource
     */
    find: (payload?: (ComponentQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ComponentRepresentation[]>;
    create: (payload?: (ComponentRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        id: string;
    }>;
    findOne: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ComponentRepresentation | undefined>;
    update: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ComponentRepresentation) => Promise<void>;
    del: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    listSubComponents: (payload?: ({
        id: string;
        type: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ComponentTypeRepresentation[]>;
    constructor(client: KeycloakAdminClient);
}
