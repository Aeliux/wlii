import type ClientScopeRepresentation from "../defs/clientScopeRepresentation.js";
import Resource from "./resource.js";
import type { KeycloakAdminClient } from "../client.js";
import type ProtocolMapperRepresentation from "../defs/protocolMapperRepresentation.js";
import type MappingsRepresentation from "../defs/mappingsRepresentation.js";
import type RoleRepresentation from "../defs/roleRepresentation.js";
export declare class ClientScopes extends Resource<{
    realm?: string;
}> {
    find: (payload?: {
        realm?: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ClientScopeRepresentation[]>;
    create: (payload?: (ClientScopeRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        id: string;
    }>;
    /**
     * Client-Scopes by id
     */
    findOne: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ClientScopeRepresentation | undefined>;
    update: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ClientScopeRepresentation) => Promise<void>;
    del: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * Default Client-Scopes
     */
    listDefaultClientScopes: (payload?: (void & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ClientScopeRepresentation[]>;
    addDefaultClientScope: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    delDefaultClientScope: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * Default Optional Client-Scopes
     */
    listDefaultOptionalClientScopes: (payload?: (void & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ClientScopeRepresentation[]>;
    addDefaultOptionalClientScope: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    delDefaultOptionalClientScope: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * Protocol Mappers
     */
    addMultipleProtocolMappers: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ProtocolMapperRepresentation[]) => Promise<void>;
    addProtocolMapper: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: ProtocolMapperRepresentation) => Promise<void>;
    listProtocolMappers: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ProtocolMapperRepresentation[]>;
    findProtocolMapper: (payload?: ({
        id: string;
        mapperId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ProtocolMapperRepresentation | undefined>;
    findProtocolMappersByProtocol: (payload?: ({
        id: string;
        protocol: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<ProtocolMapperRepresentation[]>;
    updateProtocolMapper: (query: {
        id: string;
        mapperId: string;
    } & {
        realm?: string;
    }, payload: ProtocolMapperRepresentation) => Promise<void>;
    delProtocolMapper: (payload?: ({
        id: string;
        mapperId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * Scope Mappings
     */
    listScopeMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<MappingsRepresentation>;
    addClientScopeMappings: (query: {
        id: string;
        client: string;
    } & {
        realm?: string;
    }, payload: RoleRepresentation[]) => Promise<void>;
    listClientScopeMappings: (payload?: ({
        id: string;
        client: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    listAvailableClientScopeMappings: (payload?: ({
        id: string;
        client: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    listCompositeClientScopeMappings: (payload?: ({
        id: string;
        client: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    delClientScopeMappings: (query: {
        id: string;
        client: string;
    } & {
        realm?: string;
    }, payload: RoleRepresentation[]) => Promise<void>;
    addRealmScopeMappings: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: RoleRepresentation[]) => Promise<void>;
    listRealmScopeMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    listAvailableRealmScopeMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    listCompositeRealmScopeMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    delRealmScopeMappings: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: RoleRepresentation[]) => Promise<void>;
    constructor(client: KeycloakAdminClient);
    /**
     * Find client scope by name.
     */
    findOneByName(payload: {
        realm?: string;
        name: string;
    }): Promise<ClientScopeRepresentation | undefined>;
    /**
     * Delete client scope by name.
     */
    delByName(payload: {
        realm?: string;
        name: string;
    }): Promise<void>;
    /**
     * Find single protocol mapper by name.
     */
    findProtocolMapperByName(payload: {
        realm?: string;
        id: string;
        name: string;
    }): Promise<ProtocolMapperRepresentation | undefined>;
}
