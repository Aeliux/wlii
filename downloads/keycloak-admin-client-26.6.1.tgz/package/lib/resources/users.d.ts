import type { KeycloakAdminClient } from "../client.js";
import type CredentialRepresentation from "../defs/credentialRepresentation.js";
import type FederatedIdentityRepresentation from "../defs/federatedIdentityRepresentation.js";
import type GroupRepresentation from "../defs/groupRepresentation.js";
import type MappingsRepresentation from "../defs/mappingsRepresentation.js";
import type { RequiredActionAlias } from "../defs/requiredActionProviderRepresentation.js";
import type RoleRepresentation from "../defs/roleRepresentation.js";
import type { RoleMappingPayload } from "../defs/roleRepresentation.js";
import type UserConsentRepresentation from "../defs/userConsentRepresentation.js";
import type { UserProfileConfig, UserProfileMetadata } from "../defs/userProfileMetadata.js";
import type UserRepresentation from "../defs/userRepresentation.js";
import type UserSessionRepresentation from "../defs/userSessionRepresentation.js";
import Resource from "./resource.js";
export interface SearchQuery {
    search?: string;
}
export interface PaginationQuery {
    first?: number;
    max?: number;
}
interface UserBaseQuery {
    email?: string;
    firstName?: string;
    lastName?: string;
    username?: string;
    q?: string;
}
export interface UserQuery extends PaginationQuery, SearchQuery, UserBaseQuery {
    exact?: boolean;
    [key: string]: string | number | undefined | boolean;
}
export declare class Users extends Resource<{
    realm?: string;
}> {
    find: (payload?: (UserQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserRepresentation[]>;
    create: (payload?: (UserRepresentation & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        id: string;
    }>;
    /**
     * Single user
     */
    findOne: (payload?: ({
        id: string;
        userProfileMetadata?: boolean;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserRepresentation | undefined>;
    update: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: UserRepresentation) => Promise<void>;
    del: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    count: (payload?: (UserBaseQuery & SearchQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<number>;
    getProfile: (payload?: {
        realm?: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserProfileConfig>;
    updateProfile: (payload?: (UserProfileConfig & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserProfileConfig>;
    getProfileMetadata: (payload?: {
        realm?: string;
    } | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserProfileMetadata>;
    /**
     * role mappings
     */
    listRoleMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<MappingsRepresentation>;
    addRealmRoleMappings: (payload?: ({
        id: string;
        roles: RoleMappingPayload[];
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    listRealmRoleMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    delRealmRoleMappings: (payload?: ({
        id: string;
        roles: RoleMappingPayload[];
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    listAvailableRealmRoleMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    listCompositeRealmRoleMappings: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    /**
     * Client role mappings
     * https://www.keycloak.org/docs-api/11.0/rest-api/#_client_role_mappings_resource
     */
    listClientRoleMappings: (payload?: ({
        id: string;
        clientUniqueId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    addClientRoleMappings: (payload?: ({
        id: string;
        clientUniqueId: string;
        roles: RoleMappingPayload[];
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    delClientRoleMappings: (payload?: ({
        id: string;
        clientUniqueId: string;
        roles: RoleMappingPayload[];
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    listAvailableClientRoleMappings: (payload?: ({
        id: string;
        clientUniqueId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    listCompositeClientRoleMappings: (payload?: ({
        id: string;
        clientUniqueId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<RoleRepresentation[]>;
    /**
     * Send a update account email to the user
     * an email contains a link the user can click to perform a set of required actions.
     */
    executeActionsEmail: (payload?: ({
        id: string;
        clientId?: string;
        lifespan?: number;
        redirectUri?: string;
        actions?: (RequiredActionAlias | string)[];
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * Group
     */
    listGroups: (payload?: ({
        id: string;
        briefRepresentation?: boolean;
    } & PaginationQuery & SearchQuery & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<GroupRepresentation[]>;
    addToGroup: (payload?: ({
        id: string;
        groupId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<string>;
    delFromGroup: (payload?: ({
        id: string;
        groupId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<string>;
    countGroups: (payload?: ({
        id: string;
        search?: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<{
        count: number;
    }>;
    /**
     * Federated Identity
     */
    listFederatedIdentities: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<FederatedIdentityRepresentation[]>;
    addToFederatedIdentity: (payload?: ({
        id: string;
        federatedIdentityId: string;
        federatedIdentity: FederatedIdentityRepresentation;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    delFromFederatedIdentity: (payload?: ({
        id: string;
        federatedIdentityId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * remove totp
     */
    removeTotp: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * reset password
     */
    resetPassword: (payload?: ({
        id: string;
        credential: CredentialRepresentation;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    getUserStorageCredentialTypes: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<string[]>;
    /**
     * get user credentials
     */
    getCredentials: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<CredentialRepresentation[]>;
    /**
     * delete user credentials
     */
    deleteCredential: (payload?: ({
        id: string;
        credentialId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * update a credential label for a user
     */
    updateCredentialLabel: (query: {
        id: string;
        credentialId: string;
    } & {
        realm?: string;
    }, payload: string) => Promise<void>;
    moveCredentialPositionDown: (payload?: ({
        id: string;
        credentialId: string;
        newPreviousCredentialId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    moveCredentialPositionUp: (payload?: ({
        id: string;
        credentialId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * send verify email
     */
    sendVerifyEmail: (payload?: ({
        id: string;
        clientId?: string;
        redirectUri?: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * list user sessions
     */
    listSessions: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserSessionRepresentation[]>;
    /**
     * list offline sessions associated with the user and client
     */
    listOfflineSessions: (payload?: ({
        id: string;
        clientId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserSessionRepresentation[]>;
    /**
     * logout user from all sessions
     */
    logout: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    /**
     * list consents granted by the user
     */
    listConsents: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<UserConsentRepresentation[]>;
    impersonation: (query: {
        id: string;
    } & {
        realm?: string;
    }, payload: {
        user: string;
        realm: string;
    }) => Promise<Record<string, any>>;
    /**
     * revoke consent and offline tokens for particular client from user
     */
    revokeConsent: (payload?: ({
        id: string;
        clientId: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<void>;
    getUnmanagedAttributes: (payload?: ({
        id: string;
    } & {
        realm?: string;
    }) | undefined, options?: Pick<import("./agent.js").RequestArgs, "catchNotFound">) => Promise<Record<string, string[]>>;
    constructor(client: KeycloakAdminClient);
}
export {};
