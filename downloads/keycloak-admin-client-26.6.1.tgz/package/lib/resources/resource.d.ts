import type { KeycloakAdminClient } from "../client.js";
import { RequestArgs } from "./agent.js";
export default class Resource<ParamType = {}> {
    #private;
    constructor(client: KeycloakAdminClient, settings?: {
        path?: string;
        getUrlParams?: () => Record<string, any>;
        getBaseUrl?: () => string;
    });
    makeRequest: <PayloadType = any, ResponseType = any>(args: RequestArgs) => ((payload?: PayloadType & ParamType, options?: Pick<RequestArgs, "catchNotFound">) => Promise<ResponseType>);
    makeUpdateRequest: <QueryType = any, PayloadType = any, ResponseType = any>(args: RequestArgs) => ((query: QueryType & ParamType, payload: PayloadType) => Promise<ResponseType>);
}
