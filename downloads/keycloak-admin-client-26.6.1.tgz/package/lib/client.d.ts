import type { RequestArgs } from "./resources/agent.js";
import { AttackDetection } from "./resources/attackDetection.js";
import { AuthenticationManagement } from "./resources/authenticationManagement.js";
import { Cache } from "./resources/cache.js";
import { ClientPolicies } from "./resources/clientPolicies.js";
import { Clients } from "./resources/clients.js";
import { ClientScopes } from "./resources/clientScopes.js";
import { Components } from "./resources/components.js";
import { Groups } from "./resources/groups.js";
import { IdentityProviders } from "./resources/identityProviders.js";
import { Realms } from "./resources/realms.js";
import { Organizations } from "./resources/organizations.js";
import { Workflows } from "./resources/workflows.js";
import { Roles } from "./resources/roles.js";
import { ServerInfo } from "./resources/serverInfo.js";
import { Users } from "./resources/users.js";
import { UserStorageProvider } from "./resources/userStorageProvider.js";
import { WhoAmI } from "./resources/whoAmI.js";
import { Credentials } from "./utils/auth.js";
export type RequestOptions = Omit<RequestInit, "signal">;
export interface TokenProvider {
    getAccessToken: () => Promise<string | undefined>;
}
export interface ConnectionConfig {
    baseUrl?: string;
    realmName?: string;
    requestOptions?: RequestOptions;
    requestArgOptions?: Pick<RequestArgs, "catchNotFound">;
    timeout?: number;
    /**
     * Enable experimental APIs (e.g., v2 API).
     * These APIs are not yet stable and may change without notice.
     * @default false
     */
    enableExperimentalApis?: boolean;
}
export declare class KeycloakAdminClient {
    #private;
    users: Users;
    userStorageProvider: UserStorageProvider;
    groups: Groups;
    roles: Roles;
    organizations: Organizations;
    workflows: Workflows;
    clients: Clients;
    realms: Realms;
    clientScopes: ClientScopes;
    clientPolicies: ClientPolicies;
    identityProviders: IdentityProviders;
    components: Components;
    serverInfo: ServerInfo;
    whoAmI: WhoAmI;
    attackDetection: AttackDetection;
    authenticationManagement: AuthenticationManagement;
    cache: Cache;
    baseUrl: string;
    realmName: string;
    scope?: string;
    accessToken?: string;
    refreshToken?: string;
    timeout?: number;
    enableExperimentalApis: boolean;
    constructor(connectionConfig?: ConnectionConfig);
    auth(credentials: Credentials): Promise<void>;
    registerTokenProvider(provider: TokenProvider): void;
    setAccessToken(token: string): void;
    setRefreshToken(token: string): void;
    getAccessToken(): Promise<string | undefined>;
    isTokenExpired(): boolean;
    isRefreshTokenExpired(): boolean;
    getRequestOptions(): RequestOptions | undefined;
    getGlobalRequestArgOptions(): Pick<RequestArgs, "catchNotFound"> | undefined;
    setConfig(connectionConfig: ConnectionConfig): void;
}
