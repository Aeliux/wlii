export type GrantTypes = "client_credentials" | "password" | "refresh_token";
export interface Credentials {
    username?: string;
    password?: string;
    grantType: GrantTypes;
    clientId: string;
    clientSecret?: string;
    totp?: string;
    offlineToken?: boolean;
    refreshToken?: string;
    scopes?: string[];
}
export interface Settings {
    realmName?: string;
    baseUrl?: string;
    scope?: string;
    credentials: Credentials;
    requestOptions?: RequestInit;
}
export interface TokenResponseRaw {
    access_token: string;
    expires_in: string;
    refresh_expires_in: number;
    refresh_token: string;
    token_type: string;
    not_before_policy: number;
    session_state: string;
    scope: string;
    id_token?: string;
}
export interface TokenResponse {
    accessToken: string;
    expiresIn: string;
    refreshExpiresIn: number;
    refreshToken: string;
    tokenType: string;
    notBeforePolicy: number;
    sessionState: string;
    scope: string;
    idToken?: string;
}
export declare const getToken: (settings: Settings) => Promise<TokenResponse>;
