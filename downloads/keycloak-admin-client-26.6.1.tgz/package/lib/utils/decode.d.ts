export interface DecodedToken {
    exp?: number;
}
export declare function decodeToken(token: string): DecodedToken;
