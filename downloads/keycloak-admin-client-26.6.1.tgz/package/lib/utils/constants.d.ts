export declare const defaultBaseUrl = "http://127.0.0.1:8180";
export declare const defaultRealm = "master";
