import { type AdminRequestBuilder } from './admin/index.js';
import { type BaseRequestBuilder, type KeysToExcludeForNavigationMetadata, type NavigationMetadata, type RequestAdapter } from '@microsoft/kiota-abstractions';
/**
 * The main entry point of the SDK, exposes the configuration and the fluent API.
 */
export interface AdminClient extends BaseRequestBuilder<AdminClient> {
    /**
     * The admin property
     */
    get admin(): AdminRequestBuilder;
}
/**
 * Instantiates a new {@link AdminClient} and sets the default values.
 * @param requestAdapter The request adapter to use to execute the requests.
 */
export declare function createAdminClient(requestAdapter: RequestAdapter): AdminClient;
/**
 * Uri template for the request builder.
 */
export declare const AdminClientUriTemplate = "{+baseurl}";
/**
 * Metadata for all the navigation properties in the request builder.
 */
export declare const AdminClientNavigationMetadata: Record<Exclude<keyof AdminClient, KeysToExcludeForNavigationMetadata>, NavigationMetadata>;
