import { type WithRealmNameItemRequestBuilder } from './item/index.js';
import { type BaseRequestBuilder, type KeysToExcludeForNavigationMetadata, type NavigationMetadata } from '@microsoft/kiota-abstractions';
/**
 * Builds and executes requests for operations under /admin/api
 */
export interface ApiRequestBuilder extends BaseRequestBuilder<ApiRequestBuilder> {
    /**
     * Gets an item from the ApiSdk.admin.api.item collection
     * @param realmName Unique identifier of the item
     * @returns {WithRealmNameItemRequestBuilder}
     */
    byRealmName(realmName: string): WithRealmNameItemRequestBuilder;
}
/**
 * Uri template for the request builder.
 */
export declare const ApiRequestBuilderUriTemplate = "{+baseurl}/admin/api";
/**
 * Metadata for all the navigation properties in the request builder.
 */
export declare const ApiRequestBuilderNavigationMetadata: Record<Exclude<keyof ApiRequestBuilder, KeysToExcludeForNavigationMetadata>, NavigationMetadata>;
