import { type BaseClientRepresentation } from '../../../../../../models/index.js';
import { type BaseRequestBuilder, type RequestConfiguration, type RequestInformation, type RequestsMetadata } from '@microsoft/kiota-abstractions';
/**
 * Builds and executes requests for operations under /admin/api/{realmName}/clients/{version}/{id}
 */
export interface VersionItemRequestBuilder extends BaseRequestBuilder<VersionItemRequestBuilder> {
    /**
     * Deletes a client from the realm
     * @param requestConfiguration Configuration for the request such as headers, query parameters, and middleware options.
     */
    delete(requestConfiguration?: RequestConfiguration<object> | undefined): Promise<void>;
    /**
     * Returns a single client by its clientId
     * @param requestConfiguration Configuration for the request such as headers, query parameters, and middleware options.
     * @returns {Promise<BaseClientRepresentation>}
     */
    get(requestConfiguration?: RequestConfiguration<object> | undefined): Promise<BaseClientRepresentation | undefined>;
    /**
     * Partially updates a client using JSON Merge Patch
     * @param body Binary request body
     * @param requestConfiguration Configuration for the request such as headers, query parameters, and middleware options.
     * @returns {Promise<BaseClientRepresentation>}
     */
    patch(body: ArrayBuffer | undefined, requestConfiguration?: RequestConfiguration<object> | undefined): Promise<BaseClientRepresentation | undefined>;
    /**
     * Creates or updates a client in the realm
     * @param body Base client representation with common properties for all client types
     * @param requestConfiguration Configuration for the request such as headers, query parameters, and middleware options.
     * @returns {Promise<BaseClientRepresentation>}
     */
    put(body: BaseClientRepresentation, requestConfiguration?: RequestConfiguration<object> | undefined): Promise<BaseClientRepresentation | undefined>;
    /**
     * Deletes a client from the realm
     * @param requestConfiguration Configuration for the request such as headers, query parameters, and middleware options.
     * @returns {RequestInformation}
     */
    toDeleteRequestInformation(requestConfiguration?: RequestConfiguration<object> | undefined): RequestInformation;
    /**
     * Returns a single client by its clientId
     * @param requestConfiguration Configuration for the request such as headers, query parameters, and middleware options.
     * @returns {RequestInformation}
     */
    toGetRequestInformation(requestConfiguration?: RequestConfiguration<object> | undefined): RequestInformation;
    /**
     * Partially updates a client using JSON Merge Patch
     * @param body Binary request body
     * @param requestConfiguration Configuration for the request such as headers, query parameters, and middleware options.
     * @returns {RequestInformation}
     */
    toPatchRequestInformation(body: ArrayBuffer | undefined, requestConfiguration?: RequestConfiguration<object> | undefined): RequestInformation;
    /**
     * Creates or updates a client in the realm
     * @param body Base client representation with common properties for all client types
     * @param requestConfiguration Configuration for the request such as headers, query parameters, and middleware options.
     * @returns {RequestInformation}
     */
    toPutRequestInformation(body: BaseClientRepresentation, requestConfiguration?: RequestConfiguration<object> | undefined): RequestInformation;
}
/**
 * Uri template for the request builder.
 */
export declare const VersionItemRequestBuilderUriTemplate = "{+baseurl}/admin/api/{realmName}/clients/{version}/{id}";
/**
 * Metadata for all the requests in the request builder.
 */
export declare const VersionItemRequestBuilderRequestsMetadata: RequestsMetadata;
