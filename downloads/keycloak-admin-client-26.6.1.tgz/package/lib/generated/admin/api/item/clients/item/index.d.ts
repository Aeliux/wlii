import { type BaseClientRepresentation } from '../../../../../models/index.js';
import { type VersionItemRequestBuilder } from './item/index.js';
import { type BaseRequestBuilder, type KeysToExcludeForNavigationMetadata, type NavigationMetadata, type RequestConfiguration, type RequestInformation, type RequestsMetadata } from '@microsoft/kiota-abstractions';
/**
 * Builds and executes requests for operations under /admin/api/{realmName}/clients/{version}
 */
export interface WithVersionItemRequestBuilder extends BaseRequestBuilder<WithVersionItemRequestBuilder> {
    /**
     * Gets an item from the ApiSdk.admin.api.item.clients.item.item collection
     * @param id Unique identifier of the item
     * @returns {VersionItemRequestBuilder}
     */
    byId(id: string): VersionItemRequestBuilder;
    /**
     * Returns a list of all clients in the realm
     * @param requestConfiguration Configuration for the request such as headers, query parameters, and middleware options.
     * @returns {Promise<BaseClientRepresentation[]>}
     */
    get(requestConfiguration?: RequestConfiguration<object> | undefined): Promise<BaseClientRepresentation[] | undefined>;
    /**
     * Creates a new client in the realm
     * @param body Base client representation with common properties for all client types
     * @param requestConfiguration Configuration for the request such as headers, query parameters, and middleware options.
     * @returns {Promise<BaseClientRepresentation>}
     */
    post(body: BaseClientRepresentation, requestConfiguration?: RequestConfiguration<object> | undefined): Promise<BaseClientRepresentation | undefined>;
    /**
     * Returns a list of all clients in the realm
     * @param requestConfiguration Configuration for the request such as headers, query parameters, and middleware options.
     * @returns {RequestInformation}
     */
    toGetRequestInformation(requestConfiguration?: RequestConfiguration<object> | undefined): RequestInformation;
    /**
     * Creates a new client in the realm
     * @param body Base client representation with common properties for all client types
     * @param requestConfiguration Configuration for the request such as headers, query parameters, and middleware options.
     * @returns {RequestInformation}
     */
    toPostRequestInformation(body: BaseClientRepresentation, requestConfiguration?: RequestConfiguration<object> | undefined): RequestInformation;
}
/**
 * Uri template for the request builder.
 */
export declare const WithVersionItemRequestBuilderUriTemplate = "{+baseurl}/admin/api/{realmName}/clients/{version}";
/**
 * Metadata for all the navigation properties in the request builder.
 */
export declare const WithVersionItemRequestBuilderNavigationMetadata: Record<Exclude<keyof WithVersionItemRequestBuilder, KeysToExcludeForNavigationMetadata>, NavigationMetadata>;
/**
 * Metadata for all the requests in the request builder.
 */
export declare const WithVersionItemRequestBuilderRequestsMetadata: RequestsMetadata;
