import { type ClientsRequestBuilder } from './clients/index.js';
import { type BaseRequestBuilder, type KeysToExcludeForNavigationMetadata, type NavigationMetadata } from '@microsoft/kiota-abstractions';
/**
 * Builds and executes requests for operations under /admin/api/{realmName}
 */
export interface WithRealmNameItemRequestBuilder extends BaseRequestBuilder<WithRealmNameItemRequestBuilder> {
    /**
     * The clients property
     */
    get clients(): ClientsRequestBuilder;
}
/**
 * Uri template for the request builder.
 */
export declare const WithRealmNameItemRequestBuilderUriTemplate = "{+baseurl}/admin/api/{realmName}";
/**
 * Metadata for all the navigation properties in the request builder.
 */
export declare const WithRealmNameItemRequestBuilderNavigationMetadata: Record<Exclude<keyof WithRealmNameItemRequestBuilder, KeysToExcludeForNavigationMetadata>, NavigationMetadata>;
