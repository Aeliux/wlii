import { type WithVersionItemRequestBuilder } from './item/index.js';
import { type BaseRequestBuilder, type KeysToExcludeForNavigationMetadata, type NavigationMetadata } from '@microsoft/kiota-abstractions';
/**
 * Builds and executes requests for operations under /admin/api/{realmName}/clients
 */
export interface ClientsRequestBuilder extends BaseRequestBuilder<ClientsRequestBuilder> {
    /**
     * Gets an item from the ApiSdk.admin.api.item.clients.item collection
     * @param version Unique identifier of the item
     * @returns {WithVersionItemRequestBuilder}
     */
    byVersion(version: string): WithVersionItemRequestBuilder;
}
/**
 * Uri template for the request builder.
 */
export declare const ClientsRequestBuilderUriTemplate = "{+baseurl}/admin/api/{realmName}/clients";
/**
 * Metadata for all the navigation properties in the request builder.
 */
export declare const ClientsRequestBuilderNavigationMetadata: Record<Exclude<keyof ClientsRequestBuilder, KeysToExcludeForNavigationMetadata>, NavigationMetadata>;
