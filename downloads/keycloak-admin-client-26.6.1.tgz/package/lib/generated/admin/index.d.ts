import { type ApiRequestBuilder } from './api/index.js';
import { type BaseRequestBuilder, type KeysToExcludeForNavigationMetadata, type NavigationMetadata } from '@microsoft/kiota-abstractions';
/**
 * Builds and executes requests for operations under /admin
 */
export interface AdminRequestBuilder extends BaseRequestBuilder<AdminRequestBuilder> {
    /**
     * The api property
     */
    get api(): ApiRequestBuilder;
}
/**
 * Uri template for the request builder.
 */
export declare const AdminRequestBuilderUriTemplate = "{+baseurl}/admin";
/**
 * Metadata for all the navigation properties in the request builder.
 */
export declare const AdminRequestBuilderNavigationMetadata: Record<Exclude<keyof AdminRequestBuilder, KeysToExcludeForNavigationMetadata>, NavigationMetadata>;
