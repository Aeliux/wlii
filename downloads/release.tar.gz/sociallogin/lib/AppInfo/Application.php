<?php

namespace OCA\SocialLogin\AppInfo;

use OCA\SocialLogin\AlternativeLogin\DefaultLoginShow;
use OCA\SocialLogin\Db\ConnectedLoginMapper;
use OCA\SocialLogin\Service\ProviderService;
use OCP\AppFramework\App;
use OCP\AppFramework\Bootstrap\IBootContext;
use OCP\AppFramework\Bootstrap\IBootstrap;
use OCP\AppFramework\Bootstrap\IRegistrationContext;
use OCP\EventDispatcher\IEventDispatcher;
use OCP\IAppConfig;
use OCP\IConfig;
use OCP\IRequest;
use OCP\ISession;
use OCP\IUserSession;
use OCP\User\Events\BeforeUserDeletedEvent;
use OCP\User\Events\UserLoggedOutEvent;
use OCP\Util;

class Application extends App implements IBootstrap
{
    private $appName = 'sociallogin';
    private $regContext;

    public function __construct()
    {
        parent::__construct($this->appName);
    }

    public function register(IRegistrationContext $context): void
    {
        require __DIR__ . '/../../3rdparty/autoload.php';

        $this->regContext = $context;
    }

    public function boot(IBootContext $context): void
    {
        Util::addStyle($this->appName, 'styles');

        $config = $this->query(IConfig::class);
        $appConfig = $this->query(IAppConfig::class);

        $dispatcher = $this->query(IEventDispatcher::class);
        $dispatcher->addListener(BeforeUserDeletedEvent::class, [$this, 'preDeleteUser']);

        $userSession = $this->query(IUserSession::class);
        if ($userSession->isLoggedIn()) {
            $uid = $userSession->getUser()->getUID();
            $session = $this->query(ISession::class);
            if ($config->getUserValue($uid, $this->appName, 'disable_password_confirmation')) {
                $session->set('last-password-confirm', time());
            }
            if ($logoutUrl = $session->get('sociallogin_logout_url')) {
                $dispatcher->addListener(UserLoggedOutEvent::class, function () use ($logoutUrl) {
                    header('Location: ' . $logoutUrl);
                    exit();
                });
            }
            return;
        }

        if ($appConfig->getValueBool($this->appName, 'hide_social_login')) {
            return;
        }

        $providerService = $this->query(ProviderService::class);
        $request = $this->query(IRequest::class);

        $providersCount = 0;
        $loginClass = '';
        $providers = $appConfig->getValueArray($this->appName, 'oauth_providers');
        foreach ($providers as $name => $provider) {
            if ($provider['appid']) {
                ++$providersCount;
                $loginClass = $providerService->getLoginClass($name);
                $this->regContext->registerAlternativeLogin($loginClass);
            }
        }

        $providers = $appConfig->getValueArray($this->appName, 'custom_providers');
        foreach ($providers as $providersType => $providerList) {
            foreach ($providerList as $provider) {
                ++$providersCount;
                $loginClass = $providerService->getLoginClass($provider['name'], $provider, $providersType);
                $this->regContext->registerAlternativeLogin($loginClass);
            }
        }

        if (PHP_SAPI !== 'cli') {
            $useLoginRedirect = $providersCount === 1
                && $request->getMethod() === 'GET'
                && !$request->getParam('noredir')
                && $config->getSystemValue('social_login_auto_redirect', false);
            if ($useLoginRedirect && $request->getPathInfo() === '/login') {
                $login = $this->query($loginClass);
                $login->load();
                header('Location: ' . $login->getLink());
                exit();
            }

            $hideDefaultLogin = $providersCount > 0 && $appConfig->getValueBool($this->appName, 'hide_default_login');
            if ($hideDefaultLogin && $request->getPathInfo() === '/login') {
                $this->regContext->registerAlternativeLogin(DefaultLoginShow::class);
            }
        }
    }

    public function preDeleteUser(BeforeUserDeletedEvent $event)
    {
        $user = $event->getUser();
        $this->query(ConnectedLoginMapper::class)->disconnectAll($user->getUID());
    }

    private function query($className)
    {
        return $this->getContainer()->get($className);
    }
}
